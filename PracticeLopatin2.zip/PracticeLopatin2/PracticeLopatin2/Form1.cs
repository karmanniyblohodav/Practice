﻿using System;
using System.Data;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace ExcelAutomationVar14
{
    public partial class Form1 : Form
    {
        private DataTable table;

        public Form1()
        {
            InitializeComponent();
            this.Text = "Задание №2 выполнил: Лопатин А.А.; Номер варианта: 14; Дата выполнения: "
                        + DateTime.Now.ToShortDateString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            table = new DataTable();
            table.Columns.Add("№ п/п");
            table.Columns.Add("Наименование оборудования");
            table.Columns.Add("№ по схеме");
            table.Columns.Add("К (ресурс)");
            table.Columns.Add("Т (ресурс)");
            table.Columns.Add("Дата последнего К");
            table.Columns.Add("Дата последнего Т");

            string[] months = { "январь","февраль","март","апрель","май","июнь","июль",
                                "август","сентябрь","октябрь","ноябрь","декабрь" };
            foreach (var m in months)
                table.Columns.Add(m);

            table.Columns.Add("Годовой простой, ч");
            table.Columns.Add("Годовой фонд рабочего времени, ч");
        }

        private void btnPreview_Click(object sender, EventArgs e)
        {
            Form preview = new Form();
            preview.Text = "Предпросмотр";
            preview.Width = 1000;
            preview.Height = 400;

            DataGridView dgv = new DataGridView();
            dgv.Dock = DockStyle.Fill;
            dgv.DataSource = table;

            preview.Controls.Add(dgv);
            preview.ShowDialog();
        }

        private void btnFill_Click(object sender, EventArgs e)
        {
            table.Rows.Clear();

            string filePath = "data.txt";

            if (!System.IO.File.Exists(filePath))
            {
                MessageBox.Show("Файл с данными не найден: " + filePath);
                return;
            }

            string[] lines = System.IO.File.ReadAllLines(filePath);

            foreach (string line in lines)
            {
                if (string.IsNullOrWhiteSpace(line)) continue;

                string[] values = line.Split(';');

                table.Rows.Add(values);
            }
        }


        private void btnExport_Click(object sender, EventArgs e)
        {
            Excel.Application xlApp = new Excel.Application();
            if (xlApp == null)
            {
                MessageBox.Show("Excel не установлен!");
                return;
            }

            Excel.Workbook wb = xlApp.Workbooks.Add();
            Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];

            ws.Range["A1", "A3"].Merge();
            ws.Range["A1"].Value = "№ п/п";

            ws.Range["B1", "B3"].Merge();
            ws.Range["B1"].Value = "НАИМЕНОВАНИЕ ОБОРУДОВАНИЯ";

            ws.Range["C1", "C3"].Merge();
            ws.Range["C1"].Value = "№ по схеме";

            ws.Range["D1", "E2"].Merge();
            ws.Range["D1"].Value = "Нормативы ресурса между ремонтами (числитель) и пробегов (знаменатель), час.";
            ws.Cells[3, 4] = "К";
            ws.Cells[3, 5] = "Т";

            ws.Range["F1", "G2"].Merge();
            ws.Range["F1"].Value = "Дата последнего ремонта (число, месяц, год)";
            ws.Cells[3, 6] = "К";
            ws.Cells[3, 7] = "Т";

            ws.Range["H1", "S1"].Merge();
            ws.Range["H1"].Value = "УСЛОВНОЕ ОБОЗНАЧЕНИЕ РЕМОНТА";

            for (int col = 8; col <= 19; col++)
            {
                Excel.Range rng = ws.Range[ws.Cells[2, col], ws.Cells[3, col]];
                rng.Orientation = 90;
                rng.Merge();
                rng.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
                rng.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            }

            string[] months = { "январь","февраль","март","апрель","май","июнь","июль",
                        "август","сентябрь","октябрь","ноябрь","декабрь" };
            for (int i = 0; i < months.Length; i++)
            {
                ws.Cells[2, 8 + i] = months[i];
            }

            ws.Range["T1", "T3"].Merge();
            ws.Range["T1"].Value = "Годовой простой в ремонте, ч";

            ws.Range["U1", "U3"].Merge();
            ws.Range["U1"].Value = "Годовой фонд рабочего времени, ч";

            for (int r = 0; r < table.Rows.Count; r++)
            {
                for (int c = 0; c < table.Columns.Count; c++)
                {
                    ws.Cells[r + 4, c + 1] = table.Rows[r][c].ToString();
                }
            }

            Excel.Range usedRange = ws.Range["A1", "U" + (table.Rows.Count + 4)];
            usedRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
            usedRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
            usedRange.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
            usedRange.WrapText = true;

            ws.Columns[1].ColumnWidth = 3.71;
            ws.Columns[2].ColumnWidth = 36.29;
            ws.Columns[3].ColumnWidth = 10.43;
            ws.Columns[4].ColumnWidth = 11;
            ws.Columns[5].ColumnWidth = 11;
            ws.Columns[6].ColumnWidth = 10.14;
            ws.Columns[7].ColumnWidth = 10.14;

            for (int i = 8; i <= 19; i++)
            {
                ws.Columns[i].ColumnWidth = 5;
            }

            ws.Columns[20].ColumnWidth = 10.43;
            ws.Columns[21].ColumnWidth = 12.43;

            ws.Rows[1].RowHeight = 22.5;
            ws.Rows[2].RowHeight = 41.25;
            ws.Rows[3].RowHeight = 14.25;

            for (int i = 4; i <= 8; i++)
            {
                ws.Rows[i].RowHeight = 18;
            }

            Excel.Range rngB5 = ws.Cells[5, 2];
            rngB5.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;
            rngB5.Font.Bold = true;
            rngB5.Font.Italic = true;

            Excel.Range rngB6 = ws.Cells[6, 2];
            rngB6.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;

            Excel.Range rngB7 = ws.Cells[7, 2];
            rngB7.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;

            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Excel Workbook (*.xlsx)|*.xlsx";
            sfd.Title = "Сохранить отчет как...";
            sfd.FileName = "Отчет.xlsx";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    wb.SaveAs(sfd.FileName);
                    MessageBox.Show("Файл успешно сохранен:\n" + sfd.FileName, "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка сохранения: " + ex.Message);
                }
            }

            xlApp.Visible = true;
        }

    }
}
